TSUNAMI Steal Scale Variant Pack

この版は /stealchar <mobid> scale <数値> で見た目サイズを変えられるよう、
CustomModelDataのスケール違いモデルを追加しています。

対応スケール:
- 1.0  = 通常CMD
- 1.25 = CMD + 40000
- 1.5  = CMD + 50000
- 1.75 = CMD + 60000
- 2.0  = CMD + 70000

例:
villager 1.0  = 20009
villager 1.25 = 60009
villager 1.5  = 70009
villager 1.75 = 80009
villager 2.0  = 90009

Skript fixed68以降とセットで使ってください。
