TSUNAMI Steal Shine Fix Pack

変更:
- gold_ / diamond_ テクスチャを再生成。
- 元色は使わず明暗だけを使う方式は維持しつつ、暗部を少し持ち上げて錆び感を減らしました。
- ハイライトを強め、金像/ダイヤ像っぽい輝きを出しやすくしました。
- rainbow は前回の軽い加算アニメーションを維持しています。

反映:
1. リソースパックを入れ替える
2. F3 + T
3. /stealadmin refreshmodels
