TSUNAMI Steal Villager Fixed Pack v2

v2修正:
- assets/minecraft/items/carrot_on_a_stick.json を select 形式から range_dispatch 形式へ戻しました。
- 以前のレーザーパックで動いていた形式に合わせています。
- 紫黒のCarrot on a Stickになる場合は、このitems定義が壊れている可能性が高いです。

テスト:
1. このzipをリソースパックとして入れる
2. F3+T またはリソースパック再選択で再読み込み
3. サーバーで:
   /minecraft:give @s minecraft:carrot_on_a_stick[minecraft:custom_model_data={floats:[20009]}] 1

村人:
- villager = 20009
- gold_villager = 21009
- diamond_villager = 22009
- rainbow_villager = 23009

それでも紫黒の場合:
- zipの中身が二重フォルダになっていないか確認
  正: zip直下に pack.mcmeta と assets がある
  誤: zip直下に tsunami_steal_villager_fixed_pack_v2/assets がある
- 他のリソースパックを一旦OFFにしてこのパックだけONにする
