TSUNAMI Steal - User Models Pack

models.zip のモデルを組み込んだリソースパックです。

追加/上書きしたモデル:
- chicken
- pig
- cow (.bbmodelから変換)
- sheep
- zombie
- skeleton（アップロード名 skelton を skeleton として導入）
- spider
- villager
- creeper

各モデルは normal / gold / diamond / rainbow のテクスチャを生成済みです。
fixed68以降の /stealchar <mobid> scale 1 / 1.25 / 1.5 / 1.75 / 2 にも対応しています。

反映:
1. このzipをリソースパックとして入れる
2. F3 + T
3. サーバーで /stealadmin refreshmodels

テスト例:
 /stealmodeltest chicken
 /stealmodeltest cow
 /stealmodeltest skeleton
 /stealmodeltest creeper

注意:
- skeletonは、アップロードファイル名が skelton だったため、内部ID skeleton に変換しています。
- 一部JSON内の #missing は自動で正しいテクスチャ参照へ置換しています。
