#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from pathlib import Path
import json, sys

def check(path):
    p = Path(path)
    data = json.loads(p.read_text(encoding="utf-8"))
    keys = set(data.keys())
    if "fallback" in keys and "elements" in keys:
        elems = data.get("elements")
        if isinstance(elems, list) and elems and isinstance(elems[0], dict) and "element" in elems[0]:
            print("NG: これはstructure/template pool系JSONの可能性が高く、アイテムモデルではありません。")
            return
    if "elements" in data and ("textures" in data or "parent" in data):
        print("OK寄り: アイテム/ブロックモデルJSONとして使える可能性があります。")
    elif "parent" in data and "textures" in data:
        print("OK寄り: parent付きアイテムモデルとして使える可能性があります。")
    else:
        print("不明/要確認: BlockbenchでJava Block/Itemとして開けるか確認してください。")
    print("keys:", sorted(keys))

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("使い方: python tools/check_model_json.py path/to/model.json")
    else:
        check(sys.argv[1])
