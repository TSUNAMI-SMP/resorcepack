#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TSUNAMI Steal - mutation auto generator

使い方:
1) 通常モデルJSONを assets/minecraft/models/item/steal/<id>.json に入れる
2) 通常テクスチャPNGを assets/minecraft/textures/item/steal/<id>.png に入れる
   例:
      skeleton.json
      skeleton.png
3) このファイルを実行:
      python tools/generate_mutations.py

生成されるもの:
- gold_<id>.json / gold_<id>.png
- diamond_<id>.json / diamond_<id>.png
- rainbow_<id>.json / rainbow_<id>.png / rainbow_<id>.png.mcmeta

注意:
- モデルJSON内の textures が minecraft:item/steal/<id> を指している想定です。
- もしNovaskin/Blockbenchから出したJSONが別パスを指している場合でも、
  textures欄の値を自動で gold_/diamond_/rainbow_ 付きへ差し替えます。
- PNGがないモデルはJSONコピーだけ行います。見た目の色変換にはPNGが必要です。
"""
from pathlib import Path
import json
from PIL import Image, ImageEnhance

ROOT = Path(__file__).resolve().parents[1]
MODELS = ROOT / "assets" / "minecraft" / "models" / "item" / "steal"
TEXTURES = ROOT / "assets" / "minecraft" / "textures" / "item" / "steal"

MUTATIONS = {
    "gold": {
        "prefix": "gold_",
        "tint": (255, 196, 38),
        "blend": 0.52,
        "brightness": 1.10,
        "contrast": 1.08,
    },
    "diamond": {
        "prefix": "diamond_",
        "tint": (80, 230, 255),
        "blend": 0.50,
        "brightness": 1.12,
        "contrast": 1.07,
    },
    "rainbow": {
        "prefix": "rainbow_",
        "tint": None,
        "blend": 0.55,
        "brightness": 1.15,
        "contrast": 1.10,
    },
}

SKIP_PREFIXES = ("gold_", "diamond_", "rainbow_")

def tint_image(img: Image.Image, tint_rgb, blend: float, brightness: float, contrast: float) -> Image.Image:
    img = img.convert("RGBA")
    base = ImageEnhance.Brightness(img).enhance(brightness)
    base = ImageEnhance.Contrast(base).enhance(contrast)

    overlay = Image.new("RGBA", base.size, tint_rgb + (255,))
    out = Image.blend(base, overlay, blend)

    # 元の透明度を維持
    out.putalpha(img.getchannel("A"))
    return out

def rainbow_image(img: Image.Image, brightness: float, contrast: float) -> Image.Image:
    img = img.convert("RGBA")
    base = ImageEnhance.Brightness(img).enhance(brightness)
    base = ImageEnhance.Contrast(base).enhance(contrast)
    w, h = base.size
    pixels = base.load()

    # 横方向に虹色を重ねる
    rainbow = [
        (255, 60, 60),
        (255, 170, 40),
        (255, 240, 60),
        (60, 255, 100),
        (60, 210, 255),
        (90, 90, 255),
        (210, 70, 255),
    ]
    out = Image.new("RGBA", (w, h))
    op = out.load()
    for y in range(h):
        for x in range(w):
            r, g, b, a = pixels[x, y]
            if a == 0:
                op[x, y] = (0, 0, 0, 0)
                continue
            c = rainbow[int((x / max(w, 1)) * len(rainbow)) % len(rainbow)]
            op[x, y] = (
                int(r * 0.45 + c[0] * 0.55),
                int(g * 0.45 + c[1] * 0.55),
                int(b * 0.45 + c[2] * 0.55),
                a,
            )
    return out

def replace_texture_refs(obj, base_id: str, mutated_id: str):
    # JSON全体を再帰的に見て、minecraft:item/steal/<base_id> などを差し替える
    if isinstance(obj, dict):
        return {k: replace_texture_refs(v, base_id, mutated_id) for k, v in obj.items()}
    if isinstance(obj, list):
        return [replace_texture_refs(v, base_id, mutated_id) for v in obj]
    if isinstance(obj, str):
        # 一般的なパスを差し替え
        candidates = [
            f"minecraft:item/steal/{base_id}",
            f"item/steal/{base_id}",
            f"minecraft:items/steal/{base_id}",
            f"items/steal/{base_id}",
            base_id,
        ]
        for c in candidates:
            if obj == c:
                if c.startswith("minecraft:item/steal/"):
                    return f"minecraft:item/steal/{mutated_id}"
                if c.startswith("item/steal/"):
                    return f"item/steal/{mutated_id}"
                if c.startswith("minecraft:items/steal/"):
                    return f"minecraft:item/steal/{mutated_id}"
                if c.startswith("items/steal/"):
                    return f"item/steal/{mutated_id}"
                return mutated_id
        # 末尾一致も救済
        if obj.endswith("/" + base_id):
            return obj[:-(len(base_id))] + mutated_id
    return obj

def generate_for_model(model_path: Path):
    base_id = model_path.stem
    if base_id.startswith(SKIP_PREFIXES):
        return []
    if base_id == "lasermodel":
        return []

    try:
        model = json.loads(model_path.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"[SKIP] JSON読込失敗: {model_path.name}: {e}")
        return []

    texture_path = TEXTURES / f"{base_id}.png"
    made = []

    for mut_name, cfg in MUTATIONS.items():
        mutated_id = cfg["prefix"] + base_id

        # JSON生成
        new_model = replace_texture_refs(model, base_id, mutated_id)

        # 念のためtextures欄がある場合は、#0/layer0/particleをmutation側に寄せる
        if isinstance(new_model, dict):
            tex = new_model.get("textures")
            if isinstance(tex, dict):
                for key, val in list(tex.items()):
                    if isinstance(val, str):
                        if val == f"minecraft:item/steal/{base_id}" or val.endswith("/" + base_id) or val == base_id:
                            tex[key] = f"minecraft:item/steal/{mutated_id}"
                if "particle" in tex and isinstance(tex["particle"], str):
                    if tex["particle"].endswith("/" + base_id) or tex["particle"] == base_id:
                        tex["particle"] = f"minecraft:item/steal/{mutated_id}"

        out_model = MODELS / f"{mutated_id}.json"
        out_model.write_text(json.dumps(new_model, ensure_ascii=False, indent=2), encoding="utf-8")
        made.append(out_model.relative_to(ROOT).as_posix())

        # PNG生成
        if texture_path.exists():
            img = Image.open(texture_path)
            if mut_name == "rainbow":
                out_img = rainbow_image(img, cfg["brightness"], cfg["contrast"])
            else:
                out_img = tint_image(img, cfg["tint"], cfg["blend"], cfg["brightness"], cfg["contrast"])
            out_tex = TEXTURES / f"{mutated_id}.png"
            out_img.save(out_tex)
            made.append(out_tex.relative_to(ROOT).as_posix())

            # Rainbowは簡易アニメ用mcmetaも作る
            if mut_name == "rainbow":
                mcmeta = {
                    "animation": {
                        "frametime": 4,
                        "interpolate": True
                    }
                }
                # 今回のrainbow画像は単一フレームなのでmcmetaは任意。不要なら削除OK。
                (TEXTURES / f"{mutated_id}.png.mcmeta").write_text(
                    json.dumps(mcmeta, ensure_ascii=False, indent=2),
                    encoding="utf-8"
                )
        else:
            print(f"[WARN] {base_id}.png がないため、{mutated_id}.png は生成できません。JSONだけ生成しました。")
    return made

def main():
    MODELS.mkdir(parents=True, exist_ok=True)
    TEXTURES.mkdir(parents=True, exist_ok=True)
    total = 0
    for model_path in sorted(MODELS.glob("*.json")):
        made = generate_for_model(model_path)
        if made:
            total += 1
            print(f"[OK] {model_path.stem}:")
            for m in made:
                print(f"  - {m}")
    print(f"完了: 通常モデル {total} 件から mutation を生成しました。")

if __name__ == "__main__":
    main()
