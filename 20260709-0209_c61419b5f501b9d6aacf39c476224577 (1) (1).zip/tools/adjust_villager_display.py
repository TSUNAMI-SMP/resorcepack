#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TSUNAMI Steal Villager Display Adjuster

このスクリプトは villager / gold_villager / diamond_villager / rainbow_villager の
display設定だけを一括変更します。

使い方:
  python tools/adjust_villager_display.py

よく使う調整:
- 防具立てで浮く → HEAD_Y をもっと小さくする 例 -18, -20
- 防具立てで地面にめり込む → HEAD_Y を大きくする 例 -12, -10
- 全体が小さい → SCALE を上げる 例 1.3
- 全体が大きい → SCALE を下げる 例 1.0
"""

from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
MODELS = ROOT / "assets" / "minecraft" / "models" / "item" / "steal"
TARGETS = ["villager", "gold_villager", "diamond_villager", "rainbow_villager"]

# ===== 調整するならここ =====
SCALE = 1.15

# 手持ち / ドロップアイテム / 額縁系
HAND_Y = 2
GROUND_Y = 2
FIXED_Y = 2

# 防具立ての頭に装備した時だけの上下位置
# 浮いているなら -18 や -20 にする
# 低すぎるなら -12 や -10 にする
HEAD_Y = -16
# =========================

display = {
    "thirdperson_righthand": {
        "rotation": [0, 0, 0],
        "translation": [0, HAND_Y, 0],
        "scale": [SCALE, SCALE, SCALE]
    },
    "thirdperson_lefthand": {
        "rotation": [0, 0, 0],
        "translation": [0, HAND_Y, 0],
        "scale": [SCALE, SCALE, SCALE]
    },
    "firstperson_righthand": {
        "rotation": [0, 0, 0],
        "translation": [0, HAND_Y, 0],
        "scale": [SCALE, SCALE, SCALE]
    },
    "firstperson_lefthand": {
        "rotation": [0, 0, 0],
        "translation": [0, HAND_Y, 0],
        "scale": [SCALE, SCALE, SCALE]
    },
    "ground": {
        "rotation": [0, 0, 0],
        "translation": [0, GROUND_Y, 0],
        "scale": [SCALE, SCALE, SCALE]
    },
    "fixed": {
        "rotation": [0, 0, 0],
        "translation": [0, FIXED_Y, 0],
        "scale": [SCALE, SCALE, SCALE]
    },
    "head": {
        "rotation": [0, 0, 0],
        "translation": [0, HEAD_Y, 0],
        "scale": [SCALE, SCALE, SCALE]
    }
}

for name in TARGETS:
    path = MODELS / f"{name}.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    data["display"] = display
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"updated: {path.relative_to(ROOT)}")

print("完了。zip化してリソースパックに入れ直し、F3+Tで再読み込みしてください。")
