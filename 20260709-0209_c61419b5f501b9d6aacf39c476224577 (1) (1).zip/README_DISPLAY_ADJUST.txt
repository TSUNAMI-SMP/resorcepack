TSUNAMI Steal Villager Unified Display Pack

変更:
- 手に持っている時のサイズを基準に、ground / fixed / head も scale 1.15 に統一
- 防具立て装備時に浮いて見える対策として head translation Y を -16 に変更
- tools/adjust_villager_display.py を追加

調整方法:
1. zipを展開
2. tools/adjust_villager_display.py をメモ帳で開く
3. SCALE / HEAD_Y を調整
4. python tools/adjust_villager_display.py を実行
5. 再zip化してリソースパックに入れる

目安:
- 防具立てで浮く: HEAD_Y を -18 / -20 にする
- 防具立てで低すぎる: HEAD_Y を -12 / -10 にする
- 全体が小さい: SCALE を 1.3 にする
- 全体が大きい: SCALE を 1.0 にする

テスト:
 /minecraft:give @s minecraft:carrot_on_a_stick[minecraft:custom_model_data={floats:[20009]}] 1

既存キャラ再適用:
 /stealadmin refreshmodels
