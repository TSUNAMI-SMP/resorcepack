TSUNAMI Steal User Models Material Fix Pack

修正内容:
- cow.bbmodel のUV座標をJavaモデル用に正しく変換し直しました。
  以前はbbmodelのピクセルUVをそのまま使っていたため、牛のテクスチャがズレていました。
- Gold / Diamond / Rainbow の色付けを変更しました。
  旧: 元の色に金/ダイヤ色を重ねるだけ
  新: 元テクスチャの明暗だけを使い、金像/ダイヤ像のような単色素材として描画

反映:
1. このzipをリソースパックとして入れる
2. F3 + T
3. /stealadmin refreshmodels

テスト:
 /stealmodeltest cow
 /stealmodeltest gold_cow
 /stealmodeltest diamond_cow
 /stealmodeltest rainbow_cow
