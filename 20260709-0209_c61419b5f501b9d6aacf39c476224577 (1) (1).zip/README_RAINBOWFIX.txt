TSUNAMI Steal Rainbow Texture Fix Pack

修正内容:
- Rainbowの質感は維持。
- テクスチャバグの原因になりやすいアニメーションmcmetaを修正。
- 非正方形テクスチャ 64x32 / 64x64 に対応するため、mcmetaに width / height / frames を明示しました。

反映:
1. このzipをリソースパックとして入れる
2. F3 + T
3. /stealadmin refreshmodels

確認:
 /stealmodeltest rainbow_cow
 /stealmodeltest rainbow_chicken
