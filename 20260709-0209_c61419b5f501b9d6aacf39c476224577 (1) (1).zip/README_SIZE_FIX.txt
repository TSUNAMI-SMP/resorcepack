TSUNAMI Steal Villager Size Fix Pack

変更:
- 投げた時のgroundサイズは維持
- 防具立ての頭(head)表示を拡大
- 手持ち(firstperson/thirdperson)表示を拡大
- villager(2).json の #missing を #1 に修正
- texture path を minecraft:item/steal/villager に修正

調整したい場合:
assets/minecraft/models/item/steal/villager.json の display.head.scale を変更してください。
大きくする: [1.6, 1.6, 1.6]
小さくする: [1.2, 1.2, 1.2]
上下位置: display.head.translation の2番目(Y)を変更。
