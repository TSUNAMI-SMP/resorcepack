TSUNAMI Steal - User Villager Model Pack

アップロードされた villager.json / villager.png を組み込んだ版です。

修正:
- texture path を minecraft:item/steal/villager に修正
- #missing の面を #1 に修正
- gold / diamond / rainbow も自動生成
- armor stand head 用 display を追加

テスト:
 /minecraft:give @s minecraft:carrot_on_a_stick[minecraft:custom_model_data={floats:[20009]}] 1
