TSUNAMI merged resource pack

Included:
- BACAP Language Pack
- TSUNAMI Steal model/resource pack

Extract priority:
BACAP was extracted first, then TSUNAMI Steal pack was extracted over it.
This keeps TSUNAMI's custom carrot_on_a_stick model definitions active.
