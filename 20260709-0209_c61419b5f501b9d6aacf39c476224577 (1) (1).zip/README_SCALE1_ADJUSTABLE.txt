TSUNAMI Steal Villager Scale 1 Adjustable Pack

変更:
- villager / gold_villager / diamond_villager / rainbow_villager の display scale を基本 1 に統一。
- 防具立て装備時の上下位置は head.translation Y = -16。
- さらに細かい高さ/サイズ/ホログラム高さは Skript fixed66 の /stealchar コマンドで調整できます。

例:
 /stealchar villager info
 /stealchar villager height -0.4
 /stealchar villager holo 2.8
 /stealchar villager scale 1.2
 /stealchar villager reset

注意:
 /stealchar scale はサーバー側の entity scale 属性が使える環境のみ反映されます。
 反映されない場合はリソースパック側のdisplay.scaleで調整してください。
