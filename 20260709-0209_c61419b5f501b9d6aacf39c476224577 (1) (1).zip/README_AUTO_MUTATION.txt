TSUNAMI Steal Auto Mutation Pack

この版は「通常モデルだけ入れれば Gold / Diamond / Rainbow を自動生成」できるスクリプト付きです。

基本手順:
1. 通常モデルJSONをここへ入れる
   assets/minecraft/models/item/steal/<id>.json

2. 通常テクスチャPNGをここへ入れる
   assets/minecraft/textures/item/steal/<id>.png

例:
   assets/minecraft/models/item/steal/villager.json
   assets/minecraft/textures/item/steal/villager.png

3. zipを一度展開した状態で実行
   python tools/generate_mutations.py

4. 自動生成される
   gold_villager.json / gold_villager.png
   diamond_villager.json / diamond_villager.png
   rainbow_villager.json / rainbow_villager.png

注意:
- 今回アップロードされた villager.json は、モデルJSONではなく村の構造物プールJSONです。
  "minecraft:village/snowy/villagers/..." のような location が入っているため、
  アイテムモデルとしては使えません。
- 正しいモデルJSONには通常:
  textures
  elements
  faces
  display
  などが入っています。
- Novaskinから落とすなら、Blockbenchで開けるモデル、またはJava Block/ItemとしてExportできるJSONを使ってください。
- ダウンロードしたJSONがentity用の場合は、Blockbenchで Java Block/Item に変換/Exportしてください。
