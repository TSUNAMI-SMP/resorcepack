TSUNAMI Steal Cow JSON + Rainbow Animation Pack

変更:
- cowを .bbmodel 版ではなく、アップロードされた cow(1).json 版に差し替え。
- Rainbow変異は、元テクスチャを残した軽めの加算タイプ虹アニメーションに変更。
- Gold/Diamondは引き続き、元色ではなく明暗だけを使った像風の単色素材。

反映:
1. このzipをリソースパックとして入れる
2. F3 + T
3. /stealadmin refreshmodels

確認:
 /stealmodeltest cow
 /stealmodeltest rainbow_cow
