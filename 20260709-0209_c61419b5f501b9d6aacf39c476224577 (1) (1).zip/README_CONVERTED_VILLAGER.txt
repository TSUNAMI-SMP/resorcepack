
CONVERTED_VILLAGER_NOTE:
- minecraft_villager.glb から villager.json / villager.png を簡易変換しました。
- Minecraft Javaのitem modelは本来キューブモデルなので、GLBの三角形メッシュを完全再現ではなく、9個の箱モデルとして近似しています。
- 元GLBメタデータでは Sketchfab / CC-BY-4.0 表記が含まれていました。公開配布する場合は作者表記が必要です。
- villagerのCustomModelData:
  normal: 20009
  gold: 21009
  diamond: 22009
  rainbow: 23009
