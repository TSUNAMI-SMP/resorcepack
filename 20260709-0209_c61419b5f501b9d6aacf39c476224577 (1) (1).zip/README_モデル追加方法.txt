TSUNAMI Steal All Characters Template Pack

このパックは、carrot_on_a_stick の CustomModelData で全キャラ分のモデルを呼び出せるようにしたテンプレートです。
既存のレーザー CustomModelData 10002 は残しています。

入れる場所:
- モデルJSON:
  assets/minecraft/models/item/steal/<model_id>.json

- テクスチャPNG:
  assets/minecraft/textures/item/steal/<model_id>.png

例:
- Skeleton 通常:
  assets/minecraft/models/item/steal/skeleton.json
  assets/minecraft/textures/item/steal/skeleton.png
  CustomModelData: 20006

- Gold Skeleton:
  assets/minecraft/models/item/steal/gold_skeleton.json
  assets/minecraft/textures/item/steal/gold_skeleton.png
  CustomModelData: 21006

- Block God:
  assets/minecraft/models/item/steal/block_god.json
  assets/minecraft/textures/item/steal/block_god.png
  CustomModelData: 20026

作業方法:
1. Novaskin/Blockbench等からモデルJSONとPNGを用意する
2. 対応する model_id の json/png を上書きする
3. JSON内の texture パスを以下の形に合わせる
   "minecraft:item/steal/<model_id>"
4. zip化してリソースパックとして読み込む

注意:
- バニラMobのentityモデルをそのまま item model として使えるとは限りません。
- ダウンロードしたモデルがEntity用の場合は、Blockbenchで Java Block/Item としてExportしてください。
- 対応表は TSUNAMI_STEAL_MODEL_ID_LIST.csv を見てください。
- まだSkript側でCustomModelDataを装備させる処理が必要です。このパックは「受け皿」です。
